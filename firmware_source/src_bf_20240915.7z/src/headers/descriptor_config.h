#pragma once

#include "stdint.h"
#include "util.h"

#define VENDOR_BLUETOOTH_SOURCE 0x01
#define VENDOR_USB_SOURCE 0x02
#define DEFAULT_VENDOR_ID 0xCD26
#define DEFAULT_PRODUCT_ID 0x10A5
#define DEFAULT_BCD_DEVICE 0x0000
#define DEFAULT_SERIAL_NUM "000000000001"


// Manufacturer             : Microsoft Corporation
// Product                  : Xbox Bluetooth Gamepad
// Serial Number            : a05a5dcd4e59

// [Microsoft Corp.]
#define MICROSOFT_VID 0x045E
#define XBOX_MANUFACTURER "Microsoft"
#define XBOX_PRODUCT "Controller"

// [Microsoft Corp.] Xbox 360 Controller
#define XBOX_360_PID 0x028E

// [Microsoft Corp.] Xbox 360 Wireless Receiver for Windows
#define XBOX_360_W_PID 0x0291

// [Microsoft Corp.] Xbox One Wireless Controller
#define XBOX_ONE_W_PID 0x02E0

// [Microsoft Corp.] Xbox One S Controller (model 1708)
#define XBOX_ONE_S_PID 0x02EA

// [Microsoft Corp.] Xbox One S Controller [Bluetooth] (model 1708)
// Menu/select button replaces share button (supports linux kernel < 6.5)
#define XBOX_ONE_S_BT_PID 0x02FD
#define XBOX_ONE_S_BT_BCD_DEVICE 0x0408
#define XBOX_ONE_S_BT_SERIAL "3033363030343037323136373239"

// [Microsoft Corp.] Xbox Elite Series 2 Controller (model 1797)
#define XBOX_ELITE_SERIES_2_PID 0x0B00
#define XBOX_ELITE_SERIES_2_BCD_DEVICE 0x0409
#define XBOX_ELITE_SERIES_2_SERIAL "3032363330303437373233303433"

// [Microsoft Corp.] Xbox Series X Controller (model 1914)
// Share button valid
#define XBOX_SERIES_X_PID 0x0B13
#define XBOX_SERIES_X_BCD_DEVICE 0x0509
#define XBOX_SERIES_X_SERIAL "3039373130303637313034303231"

// [Sony Corp.]
#define SONY_VID 0x054C
#define DS_MANUFACTURER "Sony Interactive Entertainment"
#define DS_PRODUCT "Wireless Controller"

// [Sony Corp.] DualShock 3 / PlayStation 3 Controller
#define DUAL_SHOCK_3_PID 0x0268

// [Sony Corp.] DualShock 4 [CUH-ZCT1x]
#define DUAL_SHOCK_4_PID 0x05C4

// [Sony Corp.] DualShock 4 [CUH-ZCT2x]
#define DUAL_SHOCK_4_2x_PID 0x09CC
#define DUAL_SHOCK_4_2x_BCD_DEVICE 0x0100

// [Sony Corp.] DualSense wireless controller (PS5)
#define DUAL_SENSE_PID 0x0CE6
#define DUAL_SENSE_BCD_DEVICE 0x0100

// [Sony Corp.] DualSense Edge wireless controller (PS5)
#define DUAL_SENSE_EDGE_PID 0x0df2

// [Nintendo Co., Ltd]
#define NINTENDO_VID 0x057E
#define NS_MANUFACTURER "Nintendo"

// [Nintendo Co., Ltd] Switch Pro Controller
#define NS_PRO_PID 0x2009
#define NS_PRO_BCD_DEVICE 0x0210

// [Hori Co., Ltd] HORIPAD for Nintendo Switch
#define HORIPAD_NS_VID 0x0F0D
#define HORIPAD_NS_PID 0x00C1

// [Input Labs.]
#define ALPAKKA_VID 0x0170

// [Input Labs.] Alpakka (Xinput)
#define ALPAKKA_XUSB_PID 0xA09C

// [Input Labs.] Alpakka (HID complilant gamepad)
#define ALPAKKA_HID_PID 0xA09D

// PS3/PC Gamepad
#define PS3_PC_GAMEPAD_VID 0x2563
#define PS3_PC_GAMEPAD_PID 0x0575

// Andriod Gamepad
#define ANDRIOD_GAMEPAD_VID 0x2563
#define ANDRIOD_GAMEPAD_PID 0x0526

#define HID_ITF_PROTOCOL_NONE 0
#define TUSB_DESC_INTERFACE 0x04
#define TUSB_CLASS_HID 0x03
#define HID_SUBCLASS_BOOT 0x01
#define HID_DESC_TYPE_HID 0x21
#define HID_DESC_TYPE_REPORT 0x22
#define TUSB_DESC_ENDPOINT 0x05
#define TUSB_XFER_INTERRUPT 0x03
#define TUSB_CLASS_VENDOR_SPECIFIC 0xFF
#define TUSB_XFER_BULK 0x02

// HID Input only descriptor
// Interface number, string index, protocol, report descriptor len, EP In address, size & polling interval
#define TUD_HID_DESCRIPTOR_T(_itfnum, _stridx, _boot_protocol, _report_desc_len, _epin, _epsize, _ep_interval) \
  /* Interface */\
  9, TUSB_DESC_INTERFACE, _itfnum, 0, 1, TUSB_CLASS_HID, (uint8_t)((_boot_protocol) ? (uint8_t)HID_SUBCLASS_BOOT : 0), _boot_protocol, _stridx,\
  /* HID descriptor */\
  9, HID_DESC_TYPE_HID, UINT16_TO_BYTE(0x0111), 0, 1, HID_DESC_TYPE_REPORT, UINT16_TO_BYTE(_report_desc_len),\
  /* Endpoint In */\
  7, TUSB_DESC_ENDPOINT, _epin, TUSB_XFER_INTERRUPT, UINT16_TO_BYTE(_epsize), _ep_interval

// Interface number, string index, EP Out & IN address, EP size
#define TUD_VENDOR_DESCRIPTOR_T(_itfnum, _stridx, _epout, _epin, _epsize) \
  /* Interface */\
  9, TUSB_DESC_INTERFACE, _itfnum, 0, 2, TUSB_CLASS_VENDOR_SPECIFIC, 0x00, 0x00, _stridx,\
  /* Endpoint Out */\
  7, TUSB_DESC_ENDPOINT, _epout, TUSB_XFER_BULK, UINT16_TO_BYTE(_epsize), 0,\
  /* Endpoint In */\
  7, TUSB_DESC_ENDPOINT, _epin, TUSB_XFER_BULK, UINT16_TO_BYTE(_epsize), 0


typedef struct
{
    uint16_t idVendor;
    uint16_t idProduct;
    uint16_t report_descriptor_len;
    uint8_t report_descriptor[600];
    uint8_t descriptor_configuration[150];
} descriptor_config_t;

void descriptor_config_init(void);
descriptor_config_t get_descriptor_config(void);
