#pragma once

#include <stdint.h>

#define UINT16_TO_BYTE(n) ((uint8_t)(n)), ((uint8_t)((n) >> 8))
#define HI_UINT16(a) (((a) >> 8) & 0xFF)
#define LO_UINT16(a) ((a) & 0xFF)

uint16_t memory_copy(void* dest, const void* src, uint16_t size);
