#include <stdint.h>

uint16_t memory_copy(void* dest, const void* src, const uint16_t size)
{
    uint8_t* _dest = (uint8_t*)dest;
    const uint8_t* _src = (const uint8_t*)src;
    for (uint16_t i = 0; i < size; i++)
    {
        _dest[i] = _src[i];
    }
    return size;
}