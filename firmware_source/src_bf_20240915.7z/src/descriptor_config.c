#include <stdint.h>
#include <stdbool.h>
#include "descriptor_config.h"
#include "config.h"
#include "util.h"
#include "tusb_config.h"
#include "keybrd.h"
#include "mouse.h"
#include "switch_pro.h"

static bool descriptor_config_be_init = false;
static descriptor_config_t descriptor_config;

const uint8_t generic_report_map[] = {
    0x05, 0x01,       // USAGE_PAGE (Generic Desktop)
    0x09, 0x05,       // USAGE (Game Pad)
    0xa1, 0x01,       // COLLECTION (Application)
    0x85, 0x01,       //   REPORT_ID (1)
    0x05, 0x01,       //   USAGE_PAGE (Generic Desktop)
    0x09, 0x30,       //   USAGE (X)
    0x09, 0x31,       //   USAGE (Y)
    0x09, 0x33,       //   USAGE (Rx)
    0x09, 0x34,       //   USAGE (Ry)
    0x09, 0x32,       //   USAGE (Z)
    0x09, 0x35,       //   USAGE (Rz)
    0x16, 0x01, 0x80, //   LOGICAL_MINIMUM (-32767)
    0x26, 0xff, 0x7f, //   LOGICAL_MAXIMUM (32767)
    0x95, 0x06,       //   REPORT_COUNT (6)
    0x75, 0x10,       //   REPORT_SIZE (16)
    0x81, 0x02,       //   INPUT (Data,Var,Abs)
    0x05, 0x09,       //   USAGE_PAGE (Button)
    0x19, 0x01,       //   USAGE_MINIMUM (Button 1)
    0x29, 0x20,       //   USAGE_MAXIMUM (Button 32)
    0x15, 0x00,       //   LOGICAL_MINIMUM (0)
    0x25, 0x01,       //   LOGICAL_MAXIMUM (1)
    0x95, 0x20,       //   REPORT_COUNT (32)
    0x75, 0x01,       //   REPORT_SIZE (1)
    0x81, 0x02,       //   INPUT (Data,Var,Abs)
    0xc0              // END_COLLECTION
};

void setup_descriptor_configuration(uint8_t itfs, uint16_t report_size)
{
    uint8_t descriptor_configuration[] = {
        0x09,        /* bLength */
        0x02,        /* bDescriptorType: configuration */
        0x00, 0x00,  /* wTotalLength */
        itfs,        /* bNumInterfaces */
        0x01,        /* bConfigurationValue */
        0x00,        /* iConfiguration */
        0x80,        /* bmAttributes */
        0xFA         /* bMaxPower */
    };

    uint8_t descriptor_interface_hid[] = {
        TUD_HID_DESCRIPTOR_T(\
        ITF_HID,                /* Interface index */\
        ITF_HID + 4,            /* String index */\
        HID_ITF_PROTOCOL_NONE,  /* Boot protocol */\
        report_size,            /* Report descriptor length */\
        ADDR_HID_IN,            /* Interface address */\
        32,                     /* Endpoint buffer size */\
        1                       /* Interface interval (ms) */\
    )
    };

    uint8_t descriptor_interface_webusb[] = {
        TUD_VENDOR_DESCRIPTOR_T( \
        ITF_WEBUSB,       /* Interface index */\
        ITF_WEBUSB + 4,   /* String index */\
        ADDR_WEBUSB_OUT,  /* Address out */\
        ADDR_WEBUSB_IN,   /* Address in */\
        64                /* Size */\
    )
    };

    uint8_t descriptor_interface_xusb[] = {
        DESCRIPTOR_INTERFACE_XINPUT
    };

    uint16_t idx = 0;
    if (itfs == 1) {
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_configuration, sizeof(descriptor_configuration));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_hid, sizeof(descriptor_interface_hid));
    }
    else if (itfs == 2) {
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_configuration, sizeof(descriptor_configuration));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_hid, sizeof(descriptor_interface_hid));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_webusb, sizeof(descriptor_interface_webusb));
    }
    else if (itfs == 3) {
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_configuration, sizeof(descriptor_configuration));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_hid, sizeof(descriptor_interface_hid));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_webusb, sizeof(descriptor_interface_webusb));
        idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_interface_xusb, sizeof(descriptor_interface_xusb));
        // idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_endpoint_xusb_in, sizeof(descriptor_endpoint_xusb_in));
        // idx += memory_copy(&descriptor_config.descriptor_configuration[idx], descriptor_endpoint_xusb_out, sizeof(descriptor_endpoint_xusb_out));
    }
    descriptor_config.descriptor_configuration[2] = idx;
}

void setup_composite_report_descriptor_xusb(void)
{
    descriptor_config.report_descriptor_len = keybrd_report_map_len + custom_mouse_report_map_len;
    uint16_t idx = 0;
    idx += memory_copy(&descriptor_config.report_descriptor[idx], keybrd_report_map, keybrd_report_map_len);
    idx += memory_copy(&descriptor_config.report_descriptor[idx], custom_mouse_report_map, custom_mouse_report_map_len);
}

void setup_composite_report_descriptor_generic(void)
{
    descriptor_config.report_descriptor_len = keybrd_report_map_len + custom_mouse_report_map_len + sizeof(generic_report_map);
    uint16_t idx = 0;
    idx += memory_copy(&descriptor_config.report_descriptor[idx], keybrd_report_map, keybrd_report_map_len);
    idx += memory_copy(&descriptor_config.report_descriptor[idx], custom_mouse_report_map, custom_mouse_report_map_len);
    idx += memory_copy(&descriptor_config.report_descriptor[idx], generic_report_map, sizeof(generic_report_map));
}

void setup_composite_report_descriptor_switch_pro(void)
{
    descriptor_config.report_descriptor_len = keybrd_report_map_len + custom_mouse_report_map_len + switch_pro_report_map_len;
    uint16_t idx = 0;
    idx += memory_copy(&descriptor_config.report_descriptor[idx], keybrd_report_map, keybrd_report_map_len);
    idx += memory_copy(&descriptor_config.report_descriptor[idx], custom_mouse_report_map, custom_mouse_report_map_len);
    idx += memory_copy(&descriptor_config.report_descriptor[idx], switch_pro_report_map, switch_pro_report_map_len);
}

void descriptor_config_init(void)
{
    descriptor_config_be_init = true;
    if (config_get_protocol() == PROTOCOL_XINPUT_WIN) {
        descriptor_config.idVendor = ALPAKKA_VID;
        descriptor_config.idProduct = ALPAKKA_XUSB_PID;
        setup_composite_report_descriptor_xusb();
        setup_descriptor_configuration(3, descriptor_config.report_descriptor_len);
    }
    else if (config_get_protocol() == PROTOCOL_XINPUT_UNIX) {
        descriptor_config.idVendor = MICROSOFT_VID;
        descriptor_config.idProduct = XBOX_360_PID;
        setup_composite_report_descriptor_xusb();
        setup_descriptor_configuration(3, descriptor_config.report_descriptor_len);
    }
    else if (config_get_protocol() == PROTOCOL_GENERIC) {
        descriptor_config.idVendor = ALPAKKA_VID;
        descriptor_config.idProduct = ALPAKKA_HID_PID;
        setup_composite_report_descriptor_generic();
        setup_descriptor_configuration(2, descriptor_config.report_descriptor_len);
    }
    else if (config_get_protocol() == PROTOCOL_NSPRO) {
        descriptor_config.idVendor = NINTENDO_VID;
        descriptor_config.idProduct = NS_PRO_PID;
        setup_composite_report_descriptor_switch_pro();
        setup_descriptor_configuration(2, descriptor_config.report_descriptor_len);
    }
    else descriptor_config_be_init = false;
}

descriptor_config_t get_descriptor_config(void)
{
    if (!descriptor_config_be_init) descriptor_config_init();
    return descriptor_config;
}
