#pragma once

#include <stdint.h>

#pragma pack(push, 1)

/* HID input report id */
#define KEYBRD_HID_REPORT_INPUT_ID 0x01

extern const uint16_t keybrd_report_map_len;
extern const uint8_t keybrd_report_map[];

typedef struct
{
    // uint8_t report_id;
    uint8_t special_key;
    uint8_t key[6];
} keyboard_input_report_t;

typedef struct
{
    // uint8_t report_id;
    uint8_t special_key;
    uint8_t reserved;
    uint8_t key[6];
} keyboard_compatible_input_report_t;
