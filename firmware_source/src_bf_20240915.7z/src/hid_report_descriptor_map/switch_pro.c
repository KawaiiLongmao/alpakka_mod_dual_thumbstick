#include <stdint.h>
#include <math.h>
#include "switch_pro.h"

const uint8_t switch_pro_report_map[] = {
    0x05, 0x01,                                // Usage Page (Generic Desktop Ctrls)
    0x09, 0x05,                                // Usage (Game Pad)
    0xA1, 0x01,                                // Collection (Application)
    0x06, 0x01, 0xFF,                          //   Usage Page (Vendor Defined 0xFF01)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT_STD,                //   Report ID (33)
    0x09, 0x21,                                //   Usage (0x21)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT_FULL,               //   Report ID (48)
    0x09, 0x30,                                //   Usage (0x30)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT_NFC_MCU,            //   Report ID (49)
    0x09, 0x31,                                //   Usage (0x31)
    0x75, 0x08,                                //   Report Size (8)
    0x96, 0x69, 0x01,                          //   Report Count (361)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT_UNKNOWN1,           //   Report ID (50)
    0x09, 0x32,                                //   Usage (0x32)
    0x75, 0x08,                                //   Report Size (8)
    0x96, 0x69, 0x01,                          //   Report Count (361)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT_UNKNOWN2,           //   Report ID (51)
    0x09, 0x33,                                //   Usage (0x33)
    0x75, 0x08,                                //   Report Size (8)
    0x96, 0x69, 0x01,                          //   Report Count (361)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x85, SWITCH_PRO_HID_RPT_ID_INPUT,                    //   Report ID (63)
    0x05, 0x09,                                //   Usage Page (Button)
    0x19, 0x01,                                //   Usage Minimum (0x01)
    0x29, 0x10,                                //   Usage Maximum (0x10)
    0x15, 0x00,                                //   Logical Minimum (0)
    0x25, 0x01,                                //   Logical Maximum (1)
    0x75, 0x01,                                //   Report Size (1)
    0x95, 0x10,                                //   Report Count (16)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x05, 0x01,                                //   Usage Page (Generic Desktop Ctrls)
    0x09, 0x39,                                //   Usage (Hat switch)
    0x15, 0x00,                                //   Logical Minimum (0)
    0x25, 0x07,                                //   Logical Maximum (7)
    0x75, 0x04,                                //   Report Size (4)
    0x95, 0x01,                                //   Report Count (1)
    0x81, 0x42,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,Null State)
    0x05, 0x09,                                //   Usage Page (Button)
    0x75, 0x04,                                //   Report Size (4)
    0x95, 0x01,                                //   Report Count (1)
    0x81, 0x01,                                //   Input (Const,Array,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x05, 0x01,                                //   Usage Page (Generic Desktop Ctrls)
    0x09, 0x30,                                //   Usage (X)
    0x09, 0x31,                                //   Usage (Y)
    0x09, 0x33,                                //   Usage (Rx)
    0x09, 0x34,                                //   Usage (Ry)
    0x16, 0x00, 0x00,                          //   Logical Minimum (0)
    0x27, 0xFF, 0xFF, 0x00, 0x00,              //   Logical Maximum (65534)
    0x75, 0x10,                                //   Report Size (16)
    0x95, 0x04,                                //   Report Count (4)
    0x81, 0x02,                                //   Input (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
    0x06, 0x01, 0xFF,                          //   Usage Page (Vendor Defined 0xFF01)
    0x85, SWITCH_PRO_HID_RPT_ID_OUTPUT_RUMBLE_SUBCMD,     //   Report ID (1)
    0x09, 0x01,                                //   Usage (0x01)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x91, 0x02,                                //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x85, SWITCH_PRO_HID_RPT_ID_OUTPUT_RUMBLE,            //   Report ID (16)
    0x09, 0x10,                                //   Usage (0x10)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x91, 0x02,                                //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x85, SWITCH_PRO_HID_RPT_ID_OUTPUT_REQ_NFC_OR_RUMBLE, //   Report ID (17)
    0x09, 0x11,                                //   Usage (0x11)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x91, 0x02,                                //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0x85, SWITCH_PRO_HID_RPT_ID_OUTPUT_UNKNOWN,           //   Report ID (18)
    0x09, 0x12,                                //   Usage (0x12)
    0x75, 0x08,                                //   Report Size (8)
    0x95, 0x30,                                //   Report Count (48)
    0x91, 0x02,                                //   Output (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
    0xC0,                                      // End Collection
};

//0.0~1.0
float calcRumbleAmp(const rumble_data_t *rumble)
{
    if (rumble->freq_h == 0 && rumble->freq_h_amp == 0x01 && rumble->freq_l == 0x40 && rumble->freq_l_amp == 0x40)
        return 0;

    // ESP_LOGI(TAG, "Rumble %02x %02x %02x %02x", rumble->freq_h, rumble->freq_h_amp, rumble->freq_l, rumble->freq_l_amp);
    //老外的逆向工程文档看不懂，直接用excel表拟合他提供是数据表格
    float a; //0.0~1.0
    uint8_t ea = rumble->freq_h_amp >> 1;
    if (ea <= 1)
        a = 0.007843f * ea;
    else if (ea <= 14)
        a = 0.0084f * exp(0.1733f * ea);
    else if (ea <= 30)
        a = 0.0587f * exp(0.0433f * ea);
    else
        a = 0.115f * exp(0.0217f * ea);

    // 频率用不上直接注释掉
    // float f;
    // if (rumble->freq_h_amp & 0x01)
    // 	f = 320 * exp(0.0054f * rumble->freq_h);
    // else
    // 	f = 40 * exp(0.0217f * (rumble->freq_l & 0x7F));

    return a;
}

const uint16_t switch_pro_report_map_len = sizeof(switch_pro_report_map);
