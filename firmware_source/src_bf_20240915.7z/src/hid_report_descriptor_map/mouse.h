#pragma once

#include <stdint.h>

#pragma pack(push, 1)

/* HID input report id */
#define MOUSE_HID_REPORT_INPUT_ID 0x02

extern const uint16_t custom_mouse_report_map_len;
extern const uint8_t custom_mouse_report_map[];
extern const uint16_t mouse_report_map_len;
extern const uint8_t mouse_report_map[];

typedef struct
{
    // uint8_t report_id;
    uint8_t buttons;
    int8_t x;
    int8_t y;
    int8_t wheel;
} mouse_input_report_t;



typedef struct
{
    uint8_t buttons;
    int16_t x;
    int16_t y;
    int8_t vertical_wheel;
    int8_t horizontal_wheel;
} custom_mouse_input_report_t;
